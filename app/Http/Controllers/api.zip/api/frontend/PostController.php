<?php

    namespace App\Http\Controllers\api\frontend;

    use App\Models\Post;
    use Illuminate\Http\Request;

    use App\Http\Resources\PostResource;
    use App\Exceptions\SomethingWentWrong;

    class PostController extends Controller
    {
        /**
     * @OA\Get(
     *     tags={"Posts"},
     *     path="/api/frontend/posts",
     *     description="Listado de posts",
     *     operationId="posts",
     * @OA\Response(
     *    response=200,
     *    description="Successful Response",
     *    @OA\JsonContent(@OA\Property(property="data", type="Json", example="[...]"),
     *        )
     * ),
     * * @OA\Response(
     *    response=401,
     *    description="Bad Request",
     *    @OA\JsonContent(
     *       @OA\Property(property="message", type="string", example="Unauthenticated")
     *        )
     *     ),
     * )
     */
     public function index(){
        $posts = Post::paginate(5);
        return PostResource::collection($posts);
    }

    /**
     * @OA\Get(
     *     tags={"Posts"},
     *     path="/api-/frontend/posts/{post}",
     *     description="Mostrar un post",
     *     security={{"token": {}}},
     *     operationId="show",
     * @OA\Parameter(
     *          name="post",
     *          in="path",
     *          description="Id del post",
     *          required=true,
     *          @OA\Schema(
     *              type="integer",
     *              format="integer",
     *              example="1",
     *          )
     *      ),
     * @OA\Response(
     *    response=200,
     *    description="Successful Response",
     *    @OA\JsonContent(@OA\Property(property="data", type="Json", example="[...]"),
     *        )
     * ),
     * * @OA\Response(
     *    response=401,
     *    description="Bad Request",
     *    @OA\JsonContent(
     *       @OA\Property(property="message", type="string", example="Unauthenticated")
     *        )
     *     ),
     * )
     */
    public function show(Post $post)
    {
        return new PostResource($post);
    }


  
        
}